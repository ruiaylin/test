package im.youni.app.launcher;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * App Launcher
 */
public class AppLauncher {

    private static ClassPathXmlApplicationContext context;

    public static void main(String[] args) {
        createApplicationContext();
    }

    public static void createApplicationContext() {
        try {
            context =new ClassPathXmlApplicationContext("app.startup.xml");
            context.registerShutdownHook();
            context.start();

            System.out.println(
                    new SimpleDateFormat("yyyy/MM/dd HH:mm:ssSSS").format(new Date())
                    + "  ======== app startup ok! ========");
        } catch (Exception e) {

            System.err.println("fatal exception : " + e.getMessage());
            e.printStackTrace();
            System.exit(-1);
        }

        try {
            Thread.currentThread().join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
