mvn clean package -DskipTests -Prelease
