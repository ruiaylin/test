mvn clean package -DskipTests -Ppreview
