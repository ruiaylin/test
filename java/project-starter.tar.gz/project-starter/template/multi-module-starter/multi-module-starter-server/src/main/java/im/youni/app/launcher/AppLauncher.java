package im.youni.app.launcher;

import com.snda.youni.commons.utils.core.ObjectHolder;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * App Launcher
 */
public class AppLauncher {
    private static Logger logger = Logger.getLogger(AppLauncher.class);

    private static ClassPathXmlApplicationContext context;

    public static void main(String[] args) {
        createApplicationContext();
    }

    public static void createApplicationContext() {
        try {
            context =new ClassPathXmlApplicationContext("app.startup.xml");
            context.registerShutdownHook();
            context.start();
            ObjectHolder.put(ObjectHolder.APP_CONTEXT, context);
            
            System.out.println(
                    new SimpleDateFormat("yyyy/MM/dd HH:mm:ssSSS").format(new Date())
                            + "  ======== app startup ok! ========");
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }

        try {
            Thread.currentThread().join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
