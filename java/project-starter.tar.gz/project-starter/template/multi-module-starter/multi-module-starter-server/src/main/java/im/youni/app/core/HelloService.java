package im.youni.app.core;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

/**
 * Hello World Service
 * Created by isnail on 7/9/16.
 */
@Service
public class HelloService implements InitializingBean {
    private static final Logger log = LoggerFactory.getLogger(HelloService.class);

    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("OOooo ........ Service start successful ........");
    }
}
