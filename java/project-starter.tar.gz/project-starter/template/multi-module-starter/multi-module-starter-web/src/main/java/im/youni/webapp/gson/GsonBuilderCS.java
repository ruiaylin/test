package im.youni.webapp.gson;

import com.google.gson.Gson;
import im.youni.webapp.gson.DateTimeDeserializer;
import im.youni.webapp.gson.DateTimeSerializer;
import org.joda.time.DateTime;

/**
 * G builder
 *     Used to build custom json parser
 * Gson对象构建器
 *     用于自定义解析类型
 * <p/>
 * Created by isnail on 3/10/16.
 */
public class GsonBuilderCS {
    public static Gson build() {
       return new com.google.gson.GsonBuilder()
               .registerTypeAdapter(DateTime.class, new DateTimeSerializer())
               .registerTypeAdapter(DateTime.class, new DateTimeDeserializer())
               .disableHtmlEscaping()
               .create();
    }
}
