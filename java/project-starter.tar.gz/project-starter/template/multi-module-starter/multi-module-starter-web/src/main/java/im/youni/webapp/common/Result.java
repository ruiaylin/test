package im.youni.webapp.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.base.MoreObjects;

import java.io.Serializable;

/**
 * Common core return do
 *     - 通用业务返回封装对象Do
 * usage:
 *
 *    Result<String> fo() {
 *        // Success return
 *        return Result.of();
 *        return Result.of("hello");
 *
 *        // Fail return
 *        return Result.err(errCode);
 *        return Result.err(errCode, errMsg);
 *    }
 *
 *    Resp process() {
 *        Result<String> re = fo();
 *
 *        if (re.isErr()) {
 *            return Resp.fail(re.code(), re.msg());
 *        }
 *
 *        return Resp.success(re.get());
 *    }
 *
 *
 * Created by isnail on 3/10/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Result<T> implements Serializable{

    private static final long serialVersionUID = 6339418185676266866L;

    private final int code;
    private final String msg;
    private final T val;

    private Result(int code, String errorMsg, T val) {
        this.code = code;
        this.msg = errorMsg;
        this.val = val;
    }

    /**
     * Create result with result object
     */
    public static <T> Result<T> of(T val) {
        return new Result<>(0, null, val);
    }

    /**
     * Create success result
     * @param <T>
     * @return
     */
    public static <T> Result<T> of() {
        return new Result<>(0, null, null);
    }

    /**
     * Error with error code and msg
     */
    public static <T> Result<T> err(int code, String msg) {
        return new Result<>(code, msg, null);
    }

    /**
     * Error with error code
     */
    public static <T> Result<T> err(int code) {
        return new Result<>(code, null, null);
    }

    /**
     * Is error?
     */
    public boolean isErr() {
        return this.code != 0;
    }

    /**
     * Get result object.
     */
    public T get() {
        return val;
    }

    /**
     * Get error msg.
     */
    public String msg() {
        return msg;
    }

    /**
     * Get result code.
     */
    public int code() {
        return code;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("code", code)
                .add("msg", msg)
                .add("val", val)
                .toString();
    }
}
