package im.youni.webapp.gson;


/**
 * G(json) parser
 *      json 转换器
 *
 * Created by isnail on 6/22/16.
 */
public class G {

    private static final com.google.gson.Gson g = GsonBuilderCS.build();

    /**
     * Object to json
     * @param src
     * @return
     */
    public static <T> String toJson(T src) {
        return g.toJson(src);
    }

    /**
     * Json to object
     * @param json
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T fromJson(String json, Class<T> clazz) {
        return g.fromJson(json, clazz);
    }
}
