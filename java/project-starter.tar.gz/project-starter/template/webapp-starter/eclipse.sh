mvn clean eclipse:clean -U eclipse:eclipse
