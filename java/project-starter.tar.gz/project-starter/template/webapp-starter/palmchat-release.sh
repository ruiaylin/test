mvn -U -DskipTests clean package -Ppalmchat-release
