package im.youni.webapp.controller;

import im.youni.webapp.common.Resp;
import im.youni.webapp.common.Result;
import im.youni.webapp.service.HelloService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Hello Controller
 *
 * Created by isnail on 7/12/16.
 */
@Controller
@RequestMapping("/")
public class HelloController {

    @Autowired
    private HelloService helloService;

    /**
     * Hello
     */
    @ResponseBody
    @RequestMapping("hello")
    public Resp hello() {
        Result<String> re = helloService.hello();

        if (re.isErr()) {
            return Resp.fail(re.code(), re.msg());
        }

        return Resp.success(re.get());
    }

    /**
     * Unexpected exception test
     */
    @ResponseBody
    @RequestMapping("/ex")
    public Resp ex(){

        throw new RuntimeException("Unexpected exception!");
    }
}
