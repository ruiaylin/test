package im.youni.webapp.util.error;

/**
 * Server errors
 * usage:
 *      import static im.youni.xxx.util.ServerErrors.*;
 *
 *      EXAMPLE_ERROR.CODE
 *      EXAMPLE_ERROR.MSG
 *
 * Created by isnail on 6/3/16.
 */
public class ServerError extends ErrorBase{

    /**
     * Example
     * This is a Error Example
     */
    public static class EXAMPLE_ERROR {
        public static final int CODE = -99;
        public static final String MSG = "Just a example error!";
        public static final String I18N = "error.message.example_error";
    }
}
