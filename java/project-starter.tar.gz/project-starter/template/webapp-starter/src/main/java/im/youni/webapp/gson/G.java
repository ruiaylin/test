package im.youni.webapp.gson;

import com.google.gson.reflect.TypeToken;
import org.joda.time.DateTime;

import java.lang.reflect.Type;

/**
 * G(json) parser
 * json 转换器
 * <p>
 * Created by isnail on 6/22/16.
 */
public class G {

    private static final com.google.gson.Gson g;
    private static final com.google.gson.Gson prettyG;

    static {
        g = new com.google.gson.GsonBuilder()
                .registerTypeAdapter(DateTime.class, new DateTimeSerializer())
                .registerTypeAdapter(DateTime.class, new DateTimeDeserializer())
                .disableHtmlEscaping()
                .setDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
//               .setDateFormat("yyyy-MM-dd HH:mm:ss.SSX")  //include timezone
//               .setPrettyPrinting()
                .create();

        prettyG = new com.google.gson.GsonBuilder()
                .registerTypeAdapter(DateTime.class, new DateTimeSerializer())
                .registerTypeAdapter(DateTime.class, new DateTimeDeserializer())
                .disableHtmlEscaping()
                .setDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
//               .setDateFormat("yyyy-MM-dd HH:mm:ss.SSX")  //include timezone
                .setPrettyPrinting()
                .create();
    }

    /**
     * Object to json
     *
     * @param src T source
     * @return json string
     */
    public static <T> String toJson(T src) {
        return g.toJson(src);
    }

    /**
     * Object to json (pretty format)
     * @param src T source
     * @return json string
     */
    public static <T> String toPrettyJson(T src) {
        return prettyG.toJson(src);
    }

    /**
     * Json to object.
     *
     * @param json  json string.
     * @param clazz Obj.class.
     * @return T object.
     */
    public static <T> T fromJson(String json, Class<T> clazz) {
        return g.fromJson(json, clazz);
    }

    /**
     * Json to object by {@link TypeToken}.
     * <pre>
     *      TypeToken<Map<String, String>> mapType = new TypeToken<Map<String, String>>(){};
     * </pre>
     *
     * @param json json string.
     * @param type {@link TypeToken}.
     * @return T object.
     */
    public static <T> T fromJson(String json, TypeToken type) {
        return g.fromJson(json, type.getType());
    }

    /**
     * Json to object by {@link Type}.
     * <pre>
     *     Type mapType = new TypeToken<Map<String, String>>(){}.getType();
     * </pre>
     *
     * @param json json string.
     * @param type {@link Type}.
     * @return T object.
     */
    public static <T> T fromJson(String json, Type type) {
        return g.fromJson(json, type);
    }
}
