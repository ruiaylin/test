package im.youni.webapp.util;

import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;

import javax.servlet.ServletContextEvent;

/**
 * Spring context listener.
 * - 请使用这个Listener启动Spring上下文，这是为了Spring上下文启动有异常的话直接中断启动。
 * <p>
 * Created by isnail on 20/06/2017.
 */
public class SpringInitListener extends ContextLoaderListener {

    @Override
    public void contextInitialized(ServletContextEvent event) {
        super.contextInitialized(event);
        Object context = event.getServletContext().getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);

        if (context instanceof Throwable) {
            System.err.println("!!! Fatal: Spring initialization failed!");
            ((Throwable) context).printStackTrace();
            System.exit(-1);
        }
    }
}
