package im.youni.webapp.common;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

/**
 * Response object
 *     - 通用响应对象
 * usage:
 *     Resp.success();       // Return resultCode 0.
 *     Resp.success(obj1);   // Return resultCode 0 and data object obj1.
 *     Resp.fail(code, msg); // Return error resultCode and error msg.
 *
 * Created by isnail on 3/7/16.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Resp implements Serializable{

    private static final long serialVersionUID = 6339418185676266864L;

    /**
     * Result code
     * 响应代码
     */
    private int resultCode;

    /**
     * Error msg
     * 错误信息
     */
    private String errorMsg;

    /**
     * Response object
     * 携带内容
     */
    private Object data;


    /**
     * Success
     * 返回成功响应对象
     */
    public static Resp success(Object data) {
        Resp r = new Resp();
        r.resultCode = 0;
        r.errorMsg = "";
        r.data = data;

        return r;
    }

    /**
     * Success
     * 返回成功响应对象
     */
    public static Resp success() {
        Resp r = new Resp();
        r.resultCode = 0;
        r.errorMsg = "";
        r.data = null;

        return r;
    }

    /**
     * Fail
     * 返回失败响应对象
     */
    public static Resp fail(int resultCode) {
        Resp r = new Resp();
        r.resultCode = resultCode;
        r.errorMsg = "";
        r.data = null;

        return r;
    }

    /**
     * Fail
     * 返回失败响应对象
     */
    public static Resp fail(int resultCode, String errorMsg) {
        Resp r = new Resp();
        r.resultCode = resultCode;
        r.errorMsg = errorMsg;
        r.data = null;

        return r;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
