package im.youni.webapp.service.impl;

import im.youni.webapp.common.Result;
import im.youni.webapp.service.HelloService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Hello Service Impl (example).
 *
 * Created by isnail on 7/12/16.
 */
@Service
public class HelloServiceimpl implements HelloService{
    private static final Logger log = LoggerFactory.getLogger(HelloServiceimpl.class);

    @Override
    public Result<String>hello() {
        log.info("==== => Do Hello Service!");

        return Result.of("hello");
    }
}
