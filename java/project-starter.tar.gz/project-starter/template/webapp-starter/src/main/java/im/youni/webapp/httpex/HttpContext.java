package im.youni.webapp.httpex;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Http context helper
 * Http 上下文辅助类
 * Usage:
 * 		1. Set spring interceptor {@code HttpContextInjectInterceptor} to intercept path /**.
 * 	 		配置使用HttpCoontextInjectInterceptor拦截所有的连接。
 * 		2. Use HttpContext.currentRequest() get current HttpServletRequest.
 * 			调用HttpContext.currentRequest() 获得当前请求.
 * 		3. and more use.
 * 			currentRequest, currentResponse, getRemoteAddr, currentSession
 *
 *
 *
 *
 * Created by isnail on 3/21/16.
 */
public final class HttpContext {
	private static ThreadLocal<HttpServletRequest> request = new ThreadLocal<HttpServletRequest>();
	private static ThreadLocal<HttpServletResponse> response = new ThreadLocal<HttpServletResponse>();

	/**
	 * Current request
	 * 返回当前Http通讯用的Request
	 * @return
	 */
	public static HttpServletRequest currentRequest() { return request.get(); }

	/**
	 * Current response
	 * 返回当前Http通讯用的Response
	 * @return
	 */
	public static HttpServletResponse currentResponse() { return response.get(); }


	/**
	 * Current session
	 * 返回当前Http通讯用的Session
	 * @return
     */
	public static HttpSession currentSession() {
		if (request.get() != null)
			return request.get().getSession();
		return null;
	}

	/**
	 * Remote address
	 * 返回客户端的IP地址
	 * @return
	 */
	public static String getRemoteAddr() {
		HttpServletRequest req = currentRequest();
		if (req == null) return null;
		return req.getRemoteAddr();
	}
	
    static void setSevletRequestAndResponse(HttpServletRequest req, HttpServletResponse resp) {
		request.set(req);
		response.set(resp);
	}

	static void clearServletRequestAndResponse() {
		request.remove();
		response.remove();
	}
}
