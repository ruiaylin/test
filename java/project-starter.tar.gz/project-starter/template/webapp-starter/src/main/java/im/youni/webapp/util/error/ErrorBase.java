package im.youni.webapp.util.error;

/**
 * Server errors
 * usage:
 *      import static im.youni.xxx.util.ErrorBase.*;
 *
 *      INTERNAL_ERROR.CODE
 *      INTERNAL_ERROR.MSG
 *
 * Created by isnail on 3/9/16.
 */
public abstract class ErrorBase {

    /**
     * Server internal error
     * 服务器内部错误
     */
    public static class INTERNAL_ERROR {
        public static final int CODE = -1;
        public static final String MSG = "Server internal error!";
        public static final String I18N = "error.message.internal_error";
    }


}
