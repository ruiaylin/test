package im.youni.webapp.service;

import im.youni.webapp.common.Result;

/**
 * Hello Service (example).
 *
 * Created by isnail on 7/12/16.
 */
public interface HelloService {

    /**
     * Hello
     */
    Result<String> hello();
}
