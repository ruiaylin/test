package im.youni.webapp.httpex;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Http local thread context inject, include request and response and more.
 * 为Http辅助工具注入HTTP上下文.
 *
 * Created by isnail on 3/21/16.
 */
public class HttpContextInjectInterceptor implements HandlerInterceptor{

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // set request and response to http context
    	
        HttpContext.setSevletRequestAndResponse(request, response);
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        // clear request and response context from http context
        HttpContext.clearServletRequestAndResponse();
    }
}
