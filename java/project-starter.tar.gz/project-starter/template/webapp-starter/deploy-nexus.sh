mvn deploy -DskipTests=true
echo "finish !"
