# Project-Starter 

> Incredible convenient way of create project.

   
## Features
* Quickly create a app, webapp or multi module app.


## Usage
* Create a app named projectname:   

		# Build app.(-e eclipse, -i idea.  Is equivalent to 'mvn eclipse:eclipse')
	    ./build_app.sh projectname -e
	    	    
	- Then copy project to your work space.(Generated project in the 'dist' directory).
	    
	
* Create a webapp named projectname:

		# Build webapp.(-e eclipse, -i idea.  Is equivalent to 'mvn eclipse:eclipse')
		./build_webapp.sh projectname -e
		
	- Then copy project to your work space.(Generated project in the 'dist' directory).
	    
* Create a multi module app named projectname:

		# Build multi module app.(-e eclipse, -i idea.  Is equivalent to 'mvn eclipse:eclipse')
		# -tw => type=webapp    -ta => type=app
		./build_m_m_app.sh projectname -tw web -ta server -ta othermodule  -e
	    

* Then copy project to your work space.(Generated project in the 'dist' directory).

	    



## How to validate proj created correctly
* Just run AppLuancher.


## Project dir structure
* Comming soon...



## Versions
* v0.0.1(20160713):
	- First version, implements auto build project.
* v0.0.2(20170620):
	- Fix - problem.
	- New project standard structure(ptrace, jvmps, config).   
	- Add SpringInitListener to catch init exception.
	- Add word highlight color show.
	- Add shutdown hook param.
	- Add auto update func.
* v0.0.3(20170713):
	- add dubbo.properties to dubbo reigster cache lock problem.


## How to seek help
* 大声喊：蜗牛, come here!


