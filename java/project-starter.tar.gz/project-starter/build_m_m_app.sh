#!/bin/bash

#
#         ,  + .
#       /   _    \
#      |  (   )  |
#    __ \   ,   /___\/
#      __ ___ ___    /
# 
# Project builder.
# ====
# usage:
#     build_m_m_app.sh app_name [-type -tw web -ta app] module_name [-e Eclipse | -i IDEA](default none) 
#	  type: -tw type=webapp  -ta type=app
#     e.g.: 
#       1. Excute build_m_m_app.sh hello_proj -tw web_module -ta app_module -ta app_module  -e
#       2. Copy dist/hello_app dir to you work space
#       3. Import proj to you IDE.
#
# Created by 蜗牛(isnail) on 7/9/16.

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=>${NC} ${GREEN}Update project-starter ...${NC}"

UPDATE_RS=`git pull --all`

if [[ $UPDATE_RS != *"Already up-to-date."* ]] ; then
	echo UPDATE_RS
	echo -e "${BLUE}=>${NC} ${GREEN}project-starter update success, please run again.${NC}"	
	exit
fi

echo -e "${BLUE}=>${NC} ${GREEN}Update ok! ${NC}"

# Var
SOURCE_DIR=multi-module-starter
PAKAGE_NAME=app
APP_NAME=$1
BUILD_TYPE=none
TARGET_DIR=dist
NEW_PACKAGE_NAME=$APP_NAME

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check args
if [[ $APP_NAME == "" ]] ; then
	echo -e "${BLUE}=>${NC} !!! App name is empty."
	exit
fi

# Echo start
echo -e "${BLUE}=>${NC} OOoo... Start building ..."
echo -e "${BLUE}=>${NC} APP_NAME=${GREEN}$APP_NAME${NC}, BUILD_TYPE=${GREEN}$BUILD_TYPE${NC}"

# Recheck args
if [[ $APP_NAME == *"-"*  ]] ; then
	NEW_PACKAGE_NAME=${APP_NAME##*-}
	echo -e "${BLUE}=>${NC}  !!! ${RED}WARN: App name can not contain '-' character, the java package name will be named ${GREEN}$NEW_PACKAGE_NAME${NC}."
fi

# Clean $TARGET_DIR dir
rm -rf ./$TARGET_DIR
mkdir ./$TARGET_DIR

# Build type
for var in $@
do 
	if [[ $var == "-i" ]]; then
		BUILD_TYPE=IDEA
	elif [[ $var == "-e" ]]; then
		BUILD_TYPE=Eclipse
	fi
done 

# Copy file
echo -e "${BLUE}=>${NC} Copy files ..."
cp -rf ./template/$SOURCE_DIR $TARGET_DIR/$APP_NAME

echo -e "${BLUE}=>${NC} Processing ..."

# Process
next_type=app
sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/pom.xml		
for var in $@
do
	if [[ $var != $APP_NAME && $var != "-i" && $var != "-e" ]]; then
		if [[ $var == "-tw" ]] ; then 
			next_type=webapp
			SOURCE_DIR=multi-module-starter
			PAKAGE_NAME=webapp
			echo -e "${BLUE}=>${NC} Start process webapp $var"
			continue
		fi
		if [[ $var == "-ta" ]] ; then
			SOURCE_DIR=multi-module-starter
			PAKAGE_NAME=app
			next_type=app
			echo -e "${BLUE}=>${NC} Strart process app $var"
			continue
		fi
					
		NEW_VAR=$var
		if [[ $var == *"-"*  ]] ; then
			NEW_VAR=${var##*-}
			echo -e "${BLUE}=>${NC}  !!! ${RED}WARN: Java package name can not contain '-' character, the java package name will be named ${GREEN}$NEW_PACKAGE_NAME.$NEW_VAR${NC}."
		fi

		if [[ $next_type == app ]] ; then

			echo -e "${BLUE}=>${NC} Processing $var ..."
			cp -rf ./$TARGET_DIR/$APP_NAME/multi-module-starter-server ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var
			
			# sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/pom.xml		

			if [[ $var != 'server' ]]; then
				sed -i "" "/<module>$APP_NAME-server<\/module>/i \\
					<module>$APP_NAME-$var<\/module>" ./$TARGET_DIR/$APP_NAME/pom.xml
			fi

			sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/pom.xml
			sed -i "" "s/$APP_NAME-server/$APP_NAME-$var/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/pom.xml

			sed -i "" "s/im.youni.$PAKAGE_NAME/im.youni.$NEW_PACKAGE_NAME.$NEW_VAR/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/assembly/classpath.classworlds
			sed -i "" "s/$PAKAGE_NAME/$NEW_PACKAGE_NAME/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/assembly/classpath.classworlds
			sed -i "" "s/$SOURCE_DIR-server/$APP_NAME-$var/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/assembly/bin/common.properties

			sed -i "" "s/$SOURCE_DIR-server/$APP_NAME-$var/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/common/dubbo.properties
			sed -i "" "s/name=\"$SOURCE_DIR-server\"/name=\"$APP_NAME-$var\"/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/common/dubbo.xml
			sed -i "" "s/\"im.youni.$PAKAGE_NAME/\"im.youni.$NEW_PACKAGE_NAME.$NEW_VAR/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/common/app.startup.xml

			sed -i "" "s/client.id = $SOURCE_DIR-server/client.id = $APP_NAME-$var/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/*/*.properties

			sed -i "" "s/$SOURCE_DIR-server/$APP_NAME-$var/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/*/*.properties

			mkdir ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$NEW_PACKAGE_NAME
			mv ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$PAKAGE_NAME ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$NEW_PACKAGE_NAME/$NEW_VAR

			sed -i "" "s/im.youni.$PAKAGE_NAME/im.youni.$NEW_PACKAGE_NAME.$NEW_VAR/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$NEW_PACKAGE_NAME/$NEW_VAR/*/*.java
			sed -i "" "s/app startup ok/$APP_NAME startup ok/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$NEW_PACKAGE_NAME/$NEW_VAR/*/*.java
		fi

		if [[ $next_type == webapp ]] ; then

			echo -e "${BLUE}=>${NC} Processing $var ..."
			cp -rf ./$TARGET_DIR/$APP_NAME/multi-module-starter-web ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var

			# Change content
			# sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/pom.xml

			if [[ $var != 'server' ]]; then
				sed -i "" "/<module>$APP_NAME-server<\/module>/i \\
					<module>$APP_NAME-$var<\/module>" ./$TARGET_DIR/$APP_NAME/pom.xml
			fi

			sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/pom.xml
			sed -i "" "s/$APP_NAME-web/$APP_NAME-$var/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/pom.xml

			sed -i "" "s/im.youni.$PAKAGE_NAME/im.youni.$NEW_PACKAGE_NAME.$NEW_VAR/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/assembly/classpath.classworlds
			sed -i "" "s/$PAKAGE_NAME/$NEW_PACKAGE_NAME/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/assembly/classpath.classworlds
			sed -i "" "s/$SOURCE_DIR-web/$APP_NAME-$var/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/assembly/bin/common.properties

			sed -i "" "s/$SOURCE_DIR-web/$APP_NAME-$var/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/common/dubbo.properties
			sed -i "" "s/name=\"$SOURCE_DIR-web\"/name=\"$APP_NAME-$var\"/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/common/dubbo.xml
			sed -i "" "s/\"im.youni.$PAKAGE_NAME/\"im.youni.$NEW_PACKAGE_NAME.$NEW_VAR/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/common/app.startup.xml
			sed -i "" "s/\"im.youni.$PAKAGE_NAME/\"im.youni.$NEW_PACKAGE_NAME.$NEW_VAR/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/common/spring.mvc.context.xml
			sed -i "" "s/im.youni.$PAKAGE_NAME.util.SpringInitListener/im.youni.$NEW_PACKAGE_NAME.$NEW_VAR.util.SpringInitListener/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/webapp/WEB-INF/web.xml
			sed -i "" "s/$PAKAGE_NAME-displayname/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/webapp/WEB-INF/web.xml

			sed -i "" "s/client.id = $SOURCE_DIR-web/client.id = $APP_NAME-$var/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/*/*.properties

			sed -i "" "s/$SOURCE_DIR-web/$APP_NAME-$var/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/profiles/*/*.properties

			mkdir ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$NEW_PACKAGE_NAME
			mv ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$PAKAGE_NAME ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$NEW_PACKAGE_NAME/$NEW_VAR

			sed -i "" "s/im.youni.$PAKAGE_NAME/im.youni.$NEW_PACKAGE_NAME.$NEW_VAR/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$NEW_PACKAGE_NAME/$NEW_VAR/*/*.java
			sed -i "" "s/im.youni.$PAKAGE_NAME/im.youni.$NEW_PACKAGE_NAME.$NEW_VAR/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$NEW_PACKAGE_NAME/$NEW_VAR/*/*/*.java
			sed -i "" "s/app startup ok/$APP_NAME startup ok/g" ./$TARGET_DIR/$APP_NAME/$APP_NAME-$var/src/main/java/im/youni/$NEW_PACKAGE_NAME/$NEW_VAR/*/*.java
		fi
	fi
done

# Clean
DELS=1
DELW=1
for var in $@
do
	if [[ $var == 'server' ]]; then
		echo -e "${BLUE}=>${NC} Clean ."
		DELS=0
	fi
	if [[ $var == 'web' ]]; then
		echo -e "${BLUE}=>${NC} Clean .."
		DELW=0
	fi
done
# if [[ $DELS == 1 ]]; then
	rm -rf ./$TARGET_DIR/$APP_NAME/multi-module-starter-server
# fi
# if [[ $DELW == 1 ]]; then
	rm -rf ./$TARGET_DIR/$APP_NAME/multi-module-starter-web
# fi
if [[ $DELS == 1 ]]; then
	sed -i "" "s/<module>$APP_NAME-server<\/module>//g" ./$TARGET_DIR/$APP_NAME/pom.xml
fi

echo -e "${BLUE}=>${NC} ..."
# Maven build
if [[ $BUILD_TYPE == "IDEA" ]]; then
	echo -e "${BLUE}=>${NC} Build IDEA."
	cd ./$TARGET_DIR/$APP_NAME/
	mvn idea:idea
elif [[ $BUILD_TYPE == "Eclipse" ]] ; then
	echo -e "${BLUE}=>${NC} Build Eclipse."
	cd ./$TARGET_DIR/$APP_NAME/
	mvn eclipse:eclipse
else 
	echo -e "${BLUE}=>${NC} !!! Please init use 'mvn eclipse:eclipse' or 'mvn idea:idea'"
fi
echo -e "${BLUE}=>${NC} ..."

# Echo complete

echo -e "${BLUE}=>${NC} Build complete! Please see ${GREEN}$TARGET_DIR${NC} dir." 

