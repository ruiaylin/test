#!/bin/bash

#
#         ,  + .
#       /   _    \
#      |  (   )  |
#    __ \   ,   /___\/
#      __ ___ ___    /
# 
# Project builder.
# ====
# usage:
#     build_app.sh app_name [-e Eclipse | -i IDEA](default none)
#     e.g.: 
#       1. Excute build_app.sh hello_app -e
#       2. Copy dist/hello_app dir to you work space
#       3. Import proj to you IDE.
#
# Created by 蜗牛(isnail) on 7/9/16.

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}=>${NC} ${GREEN}Update project-starter ...${NC}"

UPDATE_RS=`git pull --all`

if [[ $UPDATE_RS != *"Already up-to-date."* ]] ; then
	echo UPDATE_RS
	echo -e "${BLUE}=>${NC} ${GREEN}project-starter update success, please run again.${NC}"	
	exit
fi

echo -e "${BLUE}=>${NC} ${GREEN}Update ok! ${NC}"

# Var
SOURCE_DIR=app-starter
PAKAGE_NAME=app
APP_NAME=$1
BUILD_TYPE=none
TARGET_DIR=dist
NEW_PACKAGE_NAME=$APP_NAME

# Check args
if [[ $APP_NAME == "" ]] ; then
	echo -e "${BLUE}=>${NC} !!! App name is empty."
	exit
fi

# Echo start
echo -e "${BLUE}=>${NC} OOoo... Start building ..."
echo -e "${BLUE}=>${NC} APP_NAME=${GREEN}$APP_NAME${NC}, BUILD_TYPE=${GREEN}$BUILD_TYPE${NC}"

# Recheck args
if [[ $APP_NAME == *"-"*  ]] ; then
	NEW_PACKAGE_NAME=${APP_NAME##*-}
	echo -e "${BLUE}=>${NC}  !!! ${RED}WARN: App name can not contain '-' character, the java package name will be named ${GREEN}$NEW_PACKAGE_NAME${NC}."
fi

# Clean $TARGET_DIR dir
rm -rf ./$TARGET_DIR
mkdir ./$TARGET_DIR

# Build type
if [[ $2 == "-i" ]]; then
	BUILD_TYPE=IDEA
elif [[ $2 == "-e" ]]; then
	BUILD_TYPE=Eclipse
fi

# Copy file
echo -e "${BLUE}=>${NC} Copy files ..."
cp -rf ./template/$SOURCE_DIR $TARGET_DIR/$APP_NAME

echo -e "${BLUE}=>${NC} Processing ..."
# Change content
sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/pom.xml

sed -i "" "s/$PAKAGE_NAME/$NEW_PACKAGE_NAME/g" ./$TARGET_DIR/$APP_NAME/assembly/classpath.classworlds
sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/assembly/bin/common.properties
sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/assembly/bin/common.properties

sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/common/dubbo.properties
sed -i "" "s/name=\"$SOURCE_DIR\"/name=\"$APP_NAME\"/g" ./$TARGET_DIR/$APP_NAME/profiles/common/dubbo.xml
sed -i "" "s/\"im.youni.$PAKAGE_NAME/\"im.youni.$NEW_PACKAGE_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/common/app.startup.xml


sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/dev/app.properties
sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/funtest/app.properties
sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/palmchat-release/app.properties

sed -i "" "s/client.id = $SOURCE_DIR/client.id = $APP_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/dev/bizlog.properties
sed -i "" "s/client.id = $SOURCE_DIR/client.id = $APP_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/funtest/bizlog.properties
sed -i "" "s/client.id = $SOURCE_DIR/client.id = $APP_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/palmchat-release/bizlog.properties

sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/dev/log4j.properties
sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/funtest/log4j.properties
sed -i "" "s/$SOURCE_DIR/$APP_NAME/g" ./$TARGET_DIR/$APP_NAME/profiles/palmchat-release/log4j.properties

mv ./$TARGET_DIR/$APP_NAME/src/main/java/im/youni/$PAKAGE_NAME ./$TARGET_DIR/$APP_NAME/src/main/java/im/youni/$NEW_PACKAGE_NAME
sed -i "" "s/im.youni.$PAKAGE_NAME/im.youni.$NEW_PACKAGE_NAME/g" ./$TARGET_DIR/$APP_NAME/src/main/java/im/youni/$NEW_PACKAGE_NAME/*/*.java
sed -i "" "s/app startup ok/$APP_NAME startup ok/g" ./$TARGET_DIR/$APP_NAME/src/main/java/im/youni/$NEW_PACKAGE_NAME/*/*.java

# Maven build
if [[ $BUILD_TYPE == "IDEA" ]]; then
	echo -e "${BLUE}=>${NC} Build IDEA."
	cd ./$TARGET_DIR/$APP_NAME/
	mvn idea:idea
elif [[ $BUILD_TYPE == "Eclipse" ]] ; then
	echo -e "${BLUE}=>${NC} Build Eclipse."
	cd ./$TARGET_DIR/$APP_NAME/
	mvn eclipse:eclipse
else 
	echo -e "${BLUE}=>${NC} ..."
fi

# Echo complete
echo -e "${BLUE}=>${NC} ..."
echo -e "${BLUE}=>${NC} ..."
echo -e "${BLUE}=>${NC} ..."
echo -e "${BLUE}=>${NC} Build complete! Please see ${GREEN}$TARGET_DIR${NC} dir." 
